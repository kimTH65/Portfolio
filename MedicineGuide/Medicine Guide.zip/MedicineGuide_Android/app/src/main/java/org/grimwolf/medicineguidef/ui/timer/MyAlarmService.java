package org.grimwolf.medicineguidef.ui.timer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import org.grimwolf.medicineguidef.DBHelper;
import org.grimwolf.medicineguidef.MainActivity;
import org.grimwolf.medicineguidef.R;

public class MyAlarmService extends Service {
    MediaPlayer mediaPlayer;
    public MyAlarmService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        int requestCode = intent.getIntExtra("requestCode",0);
        Log.e("MyAlarm Service req", String.valueOf(requestCode) );
        //노티피케이션으로 종료 버튼 만들것
        createNotification(intent.getExtras().getInt("requestCode"));
        //알람 실행시 해야할 것
        mediaPlayer = MediaPlayer.create(this, R.raw.alarm);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();

        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        mediaPlayer.reset();
        mediaPlayer.release();
    }
    private void createNotification(int requestCode) {

        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.putExtra("requestCode", requestCode);
        intent.putExtra("alarmoff", 1);
        PendingIntent mPendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");

        SQLiteDatabase db ;
        db = DBHelper.getInstance(getApplicationContext()).getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT NAME, CONTENT FROM DIA WHERE REQUESTCODE =" + requestCode,null);
        String name = "";
        String content = "";

        while (cursor.moveToNext()){
            name = cursor.getString(0);
            content = cursor.getString(1);
        }

        builder.setPriority(NotificationCompat.PRIORITY_MAX);   //우선순위
        builder.setSmallIcon(R.mipmap.ic_launcher);
        builder.setContentTitle(name+"먹을 시간");
        builder.setContentText(content);
        builder.setContentIntent(mPendingIntent);
        builder.setOngoing(true);
        builder.setDefaults(Notification.DEFAULT_VIBRATE);


        // 알림 표시
        NotificationManager notificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(new NotificationChannel("default", "기본 채널", NotificationManager.IMPORTANCE_HIGH));
        }
        startForeground(1, builder.build());
    }
}
