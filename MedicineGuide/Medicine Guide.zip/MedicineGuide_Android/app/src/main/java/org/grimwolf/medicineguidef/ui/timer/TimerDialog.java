package org.grimwolf.medicineguidef.ui.timer;


import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TimePicker;

import org.grimwolf.medicineguidef.R;

public class TimerDialog extends Dialog {
    public interface ICustomDialogEventListener {
        public void TimerDialogEvent(int hour, int min, boolean isRepeat);
    }

    private ICustomDialogEventListener onICustomDialogEventListener;

    Context mContext;               //컨택스트
    TimePicker mTimePicker;        //타임피커
    Button mOkbtn, mCancelbtn;    //확인버튼, 취소버튼
    CheckBox mRepeat;               //반복체크박스

    public TimerDialog(Context context, ICustomDialogEventListener onICustomDialogEventListener) {
        super(context);
        mContext =context;
        this.onICustomDialogEventListener = onICustomDialogEventListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowManager.LayoutParams lpWindow = new WindowManager.LayoutParams();
        lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        lpWindow.dimAmount = 0.8f;
        getWindow().setAttributes(lpWindow);

        setContentView(R.layout.timer_set);

        mTimePicker = (TimePicker)findViewById(R.id.d_timePicker);
        mOkbtn = (Button)findViewById(R.id.d_okbtn);
        mCancelbtn = (Button)findViewById(R.id.d_cancelbtn);
        mRepeat = (CheckBox)findViewById(R.id.repet);

        mOkbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hour, min;
                boolean isRepeat = mRepeat.isChecked();

                if(Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M){
                    hour= Integer.valueOf(mTimePicker.getHour());
                    min = mTimePicker.getMinute();
                }else{
                    hour = mTimePicker.getCurrentHour();
                    min = mTimePicker.getCurrentMinute();
                }

                onICustomDialogEventListener.TimerDialogEvent(hour,min, isRepeat);

                dismiss();
            }
        });
        mCancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }
}
