package org.grimwolf.medicineguidef.ui.main;

import android.arch.lifecycle.ViewModel;

public class MainViewModel extends ViewModel {
    // TODO: Implement the ViewModel

}
