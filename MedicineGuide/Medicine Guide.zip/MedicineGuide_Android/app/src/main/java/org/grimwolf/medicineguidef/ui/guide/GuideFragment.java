package org.grimwolf.medicineguidef.ui.guide;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import org.grimwolf.medicineguidef.DBHelper;
import org.grimwolf.medicineguidef.Insert;
import org.grimwolf.medicineguidef.R;
import org.grimwolf.medicineguidef.ui.main.MainFragment;
import org.grimwolf.medicineguidef.ui.timer.Frag;
import org.grimwolf.medicineguidef.ui.timer.TimerFragment;

import java.util.ArrayList;
import java.util.List;

public class GuideFragment extends Fragment {
    Context mContext;
    FragmentManager fragmentManager;

    EditText SeaTex;
    TextView Textname;
    LinearLayout line;
    SQLiteDatabase db ;
    String bool;
    String text;

    //------
    private List<String> list;
    private ListView listView;
    private SearchAdapter adapter;
    private ArrayList<String> arraylist;
    //-------

    private Button m_guideSearchBtn, m_guideBackBtn, m_guideInsertBtn;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext =context;

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        fragmentManager = getActivity().getSupportFragmentManager();
        View view = inflater.inflate(R.layout.guide_fragment, container, false);
        SeaTex = view.findViewById(R.id.SeaText);
        Textname = view.findViewById(R.id.Textname);
        line = view.findViewById(R.id.line);
        db = DBHelper.getInstance(mContext).getReadableDatabase();

        m_guideBackBtn = view.findViewById(R.id.Back);
        m_guideSearchBtn = view.findViewById(R.id.Search);
        m_guideInsertBtn = view.findViewById(R.id.Insert);


        listView = (ListView) view.findViewById(R.id.list);

        list = new ArrayList<String>();


        String[] colums = {"NAME","INFORM1","INFORM2","INFORM3","DRAW","CEHCK"};
        Cursor cursor = db.query("MED",colums,null,null,null,null,null);

        while(cursor.moveToNext())
        {
            list.add(cursor.getString(0).toString());
        }

        arraylist = new ArrayList<String>();
        arraylist.addAll(list);

        adapter = new SearchAdapter(list,mContext);

        listView.setAdapter(adapter);

        SeaTex.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2){

            }

            @Override
            public void afterTextChanged(Editable editable) {
                listView.setVisibility(View.VISIBLE);
                line.setVisibility(View.INVISIBLE);
                text = SeaTex.getText().toString();
                search(text);

            }


        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id)
            {
                TextView textV =(TextView)view.findViewById(R.id.label);
                SeaTex.setText(textV.getText().toString());
                listView.setVisibility(View.INVISIBLE);
            }
        });

        //--------------------버튼지역
        m_guideInsertBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Insert.class);
                startActivityForResult(intent, 0);
            }
        });
        m_guideSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String[] colums = {"NAME","INFORM1","INFORM2","INFORM3","DRAW","CEHCK"};
                    Cursor cursor = db.query("MED",colums,null,null,null,null,null);

                    int count = 0;

                    if (SeaTex.length() != 0) {
                        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        inflater.inflate(R.layout.view_med, line, true);

                        final Button check = (Button) line. findViewById(R.id.check);
                        TextView name = (TextView) line.findViewById(R.id.Textname);
                        TextView info1 = (TextView) line.findViewById(R.id.Textinfo1);
                        TextView info2 = (TextView) line.findViewById(R.id.Textinfo2);
                        TextView info3 = (TextView) line.findViewById(R.id.Textinfo3);
                        ImageView image = (ImageView) line.findViewById(R.id.imageView);

                        while(cursor.moveToNext())
                        {

                            if(cursor.getString(0).equals(SeaTex.getText().toString()))
                            {
                                count = 1;
                                name.setText(cursor.getString(0).toString());
                                info1.setText(cursor.getString(1).toString());
                                info2.setText(cursor.getString(2).toString());
                                info3.setText(cursor.getString(3).toString());
                                int res = getResources().getIdentifier(cursor.getString(4).toString(),"drawable",mContext.getPackageName());
                                image.setImageResource(res);


                                bool = cursor.getString(5).toString();

                                if (bool.equals("false")) {
                                    check.setText("추가하기");
                                    check.setBackgroundColor(Color.rgb(101, 205, 170));
                                    check.setTextColor(Color.WHITE);

                                } else {
                                    check.setText("제거하기");
                                    check.setBackgroundColor(Color.rgb(230, 230, 230));
                                    check.setTextColor(Color.GRAY);

                                }


                            }


                        }
                        if(count ==  0){line.removeAllViews(); count =0;}

                        check.setOnClickListener(new Button.OnClickListener(){
                            @Override
                            public void onClick(View v) {
                                String bool2;
                                if(bool.equals("false")) {
                                    check.setText("제거하기");
                                    check.setBackgroundColor(Color.rgb(230, 230, 230));
                                    check.setTextColor(Color.GRAY);
                                    bool2="true";

                                }else
                                {
                                    check.setText("추가하기");
                                    check.setBackgroundColor(Color.rgb(101, 205, 170));
                                    check.setTextColor(Color.WHITE);
                                    bool2="false";

                                }
                                bool = bool2;
                                ContentValues contentValues = new ContentValues();
                                contentValues.put("CEHCK", bool2);
                                db.update("MED",contentValues,"NAME='"+SeaTex.getText().toString()+"'",null);

                            }
                        });

                        listView.setVisibility(View.INVISIBLE);
                        line.setVisibility(View.VISIBLE);
                    }
                }catch (Exception e)
                {

                }
            }
        });
        m_guideBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.container,new MainFragment());
                fragmentTransaction.commit();
            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == getActivity().RESULT_CANCELED) {
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.container,new GuideFragment());
            fragmentTransaction.addToBackStack(null).commit();
        }
    }
    public void search(String charText) {

        list.clear();
        if(charText.length() ==0){
            list.addAll(arraylist);
        }
        else
        {
            for(int i =0; i<arraylist.size(); i++)
            {
                if(arraylist.get(i).toLowerCase().contains(charText))
                {
                    list.add(arraylist.get(i));
                }
            }
        }
        adapter.notifyDataSetChanged();
    }
}
