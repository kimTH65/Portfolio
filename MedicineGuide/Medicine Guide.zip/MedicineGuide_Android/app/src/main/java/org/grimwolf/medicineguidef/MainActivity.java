package org.grimwolf.medicineguidef;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import org.grimwolf.medicineguidef.ui.main.MainFragment;
import org.grimwolf.medicineguidef.ui.timer.AlarmStop;
import org.grimwolf.medicineguidef.ui.timer.TimerData;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static MainActivity mainActivity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity =this;
        setContentView(R.layout.main_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, MainFragment.newInstance())
                    .commitNow();
        }
        try {

            if(getIntent().getExtras().getInt("alarmoff") == 1) {
                Intent intent = new Intent(getApplicationContext(), AlarmStop.class);

                intent.putExtra("requestCode", getIntent().getExtras().getInt("requestCode"));
                startActivity(intent);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
