package org.grimwolf.medicineguidef.ui.timer;

import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Debug;
import android.util.Log;

import org.grimwolf.medicineguidef.DBHelper;
import org.grimwolf.medicineguidef.MainActivity;

public class MyAlarmReceiver extends BroadcastReceiver {
    Context mContext;
    @Override
    public void onReceive(Context context, Intent intent) {
        mContext = context;
        //Log.e("IMHERE", "Receiver");
        int requestCode = intent.getExtras().getInt("requestCode");
        UpdateTimer(requestCode);
        Intent alarmService = new Intent(context, MyAlarmService.class );
        alarmService.putExtra("requestCode", requestCode);
        Log.e("Receiver",String.valueOf(alarmService.getExtras().getInt("requestCode")));
        context.startService(alarmService);

        //알람시 메인엑티비티가 켜져있으면 종료
        MainActivity mainActivity = (MainActivity)MainActivity.mainActivity;
        if(mainActivity != null)
            mainActivity.finish();
    }
    public void UpdateTimer(int requestCode) {
        SQLiteDatabase db ;
        db = DBHelper.getInstance(mContext).getWritableDatabase();
        boolean sear= true;
        String[] colums = {"*"};
        Cursor cursor = db.rawQuery("SELECT REPEAT, STATUS FROM DIA WHERE REQUESTCODE =" + requestCode,null);


        while(cursor.moveToNext())
        {
            if(cursor.getString(0).equals(Boolean.toString(false))) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("STATUS", Boolean.toString(false));
                db.update("DIA", contentValues, "REQUESTCODE=" + requestCode + "", null);
            }
        }
    }

}

