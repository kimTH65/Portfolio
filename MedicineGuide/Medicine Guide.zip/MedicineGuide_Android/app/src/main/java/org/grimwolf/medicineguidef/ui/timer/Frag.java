package org.grimwolf.medicineguidef.ui.timer;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.grimwolf.medicineguidef.DBHelper;
import org.grimwolf.medicineguidef.R;

import java.util.ArrayList;
import java.util.List;

public class Frag extends Fragment {
    View view;
    private List<String> list1;
    private ListView listView;
    private FragAdapter adapter;
    SQLiteDatabase db;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        db= DBHelper.getInstance(getActivity()).getReadableDatabase();
        view = inflater.inflate(R.layout.frag,container,false);
        listView =view.findViewById(R.id.listv);
        list1 = new ArrayList<String>();
        String[] colums = {"NAME","INFORM2","CEHCK"};
        Cursor cursor = db.query("MED",colums,null,null,null,null,null);

        while(cursor.moveToNext())
        {
            if(cursor.getString(2).equals("true")) {
                list1.add(cursor.getString(0).toString() + " : " + cursor.getString(1).toString());
            }
        }
        adapter = new FragAdapter(list1,getActivity());
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //현재 container에 있는 프레그먼트의 함수를 사용 한다.현재 프레그먼트는 timerFragment 이다.
                String[] all =list1.get(position).split(" : ");
                String name = all[0];
                String content = all[1];
                TimerFragment timerFragment = (TimerFragment)getActivity().getSupportFragmentManager().findFragmentById(R.id.container);
                timerFragment.setmTimerContent(name, content);
            }
        });

        return view;
    }
}