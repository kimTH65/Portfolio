package org.grimwolf.medicineguidef.ui.timer;

import java.io.Serializable;

public class TimerData implements Serializable {
    private int requestCode;                //현재 타이머의 리퀘스트 코드
    private int hour;                        //시간
    private int min;                         //분
    private  boolean status;                //알람온오프
    private  boolean repeat;                //반복유무
    private String name;
    private String content;


    public TimerData(int requestCode, int hour, int min, boolean status, boolean repeat, String name, String content) {
        this.requestCode = requestCode;
        this.hour = hour;
        this.min = min;
        this.status = status;
        this.repeat = repeat;
        this.name = name;
        this.content = content;
    }
    public TimerData(){
        requestCode = 0;
        hour = 0;
        min = 0;
        status = false;
        repeat = false;
        name = "";
        content ="";
    }

    public int getHour() {
        return hour;
    }

    public int getMin() {
        return min;
    }

    public boolean isStatus() {
        return status;
    }

    public int getRequestCode() {
        return requestCode;
    }

    public boolean isRepeat() {
        return repeat;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public void setRepeat(boolean repeat) {
        this.repeat = repeat;
    }

    public void setRequestCode(int requestCode) {
        this.requestCode = requestCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "TimerData{" +
                "requestCode=" + requestCode +
                ", hour=" + hour +
                ", min=" + min +
                ", status=" + status +
                ", repeat=" + repeat +
                ", name='" + name + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}