package org.grimwolf.medicineguidef.ui.timer;

import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TimePicker;

import org.grimwolf.medicineguidef.R;

public class TimerDialogReset extends Dialog {

    public interface ICustomDialogEventListener {
        public void TimerDialogResetEvent(TimerData timerData);
        public void TimerDialogDeleteEvent();
        public void TimerDialogCancelEvent();
    }

    private TimerDialogReset.ICustomDialogEventListener onICustomDialogEventListener;
    Context mContext;
    TimerData mTimerData;

    TimePicker mTimePicker;        //타임피커
    Button mOkbtn, mCancelbtn, mAlarmoffbtn, mDeletebtn;    //확인버튼, 취소버튼 , 알람 종료, 알람 삭제
    CheckBox mRepeat;               //반복체크박스

    public TimerDialogReset(Context context, TimerData timerData, TimerDialogReset.ICustomDialogEventListener onICustomDialogEventListener) {
        super(context);
        mContext = context;
        mTimerData = timerData;
        this.onICustomDialogEventListener = onICustomDialogEventListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowManager.LayoutParams lpWindow = new WindowManager.LayoutParams();
        lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        lpWindow.dimAmount = 0.8f;
        getWindow().setAttributes(lpWindow);

        setContentView(R.layout.timer_reset);

        mTimePicker = (TimePicker)findViewById(R.id.d_r_timePicker);
        mOkbtn = (Button)findViewById(R.id.d_r_okbtn);
        mCancelbtn = (Button)findViewById(R.id.d_r_cancelbtn);
        mRepeat = (CheckBox)findViewById(R.id.d_r_repet);
        mAlarmoffbtn = (Button)findViewById(R.id.d_r_alarmoff);
        mDeletebtn = findViewById(R.id.d_r_delete);

        if(Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M){
            mTimePicker.setHour(mTimerData.getHour());
            mTimePicker.setMinute(mTimerData.getMin());
        }else{
            mTimePicker.setCurrentHour(mTimerData.getHour());
            mTimePicker.setCurrentMinute(mTimerData.getMin());
        }
        mRepeat.setChecked(mTimerData.isRepeat());

        mOkbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hour, min;
                boolean isRepeat = mRepeat.isChecked();

                if(Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M){
                    hour= Integer.valueOf(mTimePicker.getHour());
                    min = mTimePicker.getMinute();
                }else{
                    hour = mTimePicker.getCurrentHour();
                    min = mTimePicker.getCurrentMinute();
                }

                mTimerData.setHour(hour);
                mTimerData.setMin(min);
                mTimerData.setRepeat(isRepeat);
                onICustomDialogEventListener.TimerDialogResetEvent(mTimerData);
                dismiss();
            }
        });
        mAlarmoffbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onICustomDialogEventListener.TimerDialogCancelEvent();
                dismiss();
            }
        });
        mDeletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onICustomDialogEventListener.TimerDialogDeleteEvent();
                dismiss();
            }
        });
        mCancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

    }
}
