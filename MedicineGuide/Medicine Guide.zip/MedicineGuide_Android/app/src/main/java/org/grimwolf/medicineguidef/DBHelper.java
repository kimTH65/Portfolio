package org.grimwolf.medicineguidef;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    private static DBHelper sInstance;
    private static final int DB_VERSION = 19;
    private static final String DB_NAME = "MEDICINE.db";
    private static final String DLELTE =
        "DROP TABLE IF EXISTS " + "MED";
    private  static  final  String DELETE_DIA =
        "DROP TABLE IF EXISTS " + "DIA";

    private String sb = String.format(" CREATE TABLE IF NOT EXISTS MED (" +
            "NAME TEXT PRIMARY KEY," +
            "INFORM1 TEXT," +
            "INFORM2 TEXT," +
            "INFORM3 TEXT," +
            "DRAW TEXT," +
            "CEHCK TEXT);");

    private String di = String.format(" CREATE TABLE IF NOT EXISTS DIA (_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
            "REQUESTCODE INTEGER," +
            "HOUR INTEGER," +
            "MIN INTEGER," +
            "STATUS TEXT," +
            "REPEAT TEXT," +
            "NAME TEXT," +
            "CONTENT TEXT" +
            ");");

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }/*생성자*/

    public void onCreate(SQLiteDatabase db) {

        db.execSQL(sb.toString());
        db.execSQL(di.toString());

    }/* DB를 만드는역할*/
    public static DBHelper getInstance(Context context)
    {
        if(sInstance == null)
        {
            sInstance = new DBHelper(context);
        }
        return sInstance;
    }/*인스턴스 없으면 생성  (싱글톤 패턴 :하나의 클래스에 대해 어플리케이션이 시작될 때 최초의 한번만 메모리를 할당 , 단 하나의 인스턴스를 생성한다.)*/
    /*인스턴스 : 어떤 클래스에 속하는 각 객체를 인스턴스라 한다.*/
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DLELTE);
        db.execSQL(DELETE_DIA);


        onCreate(db);
        }/*버전 올라갈때(테이블 구조 변경시)*/
        }
