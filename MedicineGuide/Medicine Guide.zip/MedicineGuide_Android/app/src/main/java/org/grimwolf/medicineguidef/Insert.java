package org.grimwolf.medicineguidef;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import org.grimwolf.medicineguidef.ui.guide.GuideFragment;
public class Insert extends AppCompatActivity {
    EditText name;
    EditText src;
    EditText info1;
    EditText info2;
    EditText info3;
    SQLiteDatabase db ;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.insert_db);

        name = findViewById(R.id.Textname);
        src = findViewById(R.id.TextDraw);
        info1 = findViewById(R.id.Textinfo1);
        info2 = findViewById(R.id.Textinfo2);
        info3 = findViewById(R.id.Textinfo3);


    }

    public void Insert(View view) {

        db = DBHelper.getInstance(this).getWritableDatabase();
        boolean sear= true;
        String[] colums = {"NAME","INFORM1","INFORM2","INFORM3","DRAW","CEHCK"};
        Cursor cursor = db.query("MED",colums,null,null,null,null,null);

        while(cursor.moveToNext())
        {
            if(cursor.getString(0).toString().equals(name.getText().toString()))
            {
                ContentValues contentValues = new ContentValues();
                contentValues.put("INFORM1", info1.getText().toString());
                contentValues.put("INFORM2", info2.getText().toString());
                contentValues.put("INFORM3", info3.getText().toString());
                contentValues.put("DRAW", src.getText().toString());

                long newRow = db.update("MED",contentValues,"NAME='"+ name.getText().toString()+"'",null);
                if (newRow== -1) {
                    Toast.makeText(this, "수정실패", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "수정성공", Toast.LENGTH_SHORT).show();
                }
                sear = false;
            }
        }

        if(sear==true) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("NAME", name.getText().toString());
            contentValues.put("INFORM1", info1.getText().toString());
            contentValues.put("INFORM2", info2.getText().toString());
            contentValues.put("INFORM3", info3.getText().toString());
            contentValues.put("DRAW", src.getText().toString());
            contentValues.put("CEHCK","false");

            long newRowId1 = db.insert("MED", null, contentValues);

            if (newRowId1 == -1) {
                Toast.makeText(this, "저장실패", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "저장성공", Toast.LENGTH_SHORT).show();
            }
        }
    }
    public void Delete(View view) {
        db = DBHelper.getInstance(this).getWritableDatabase();
        String[] colums = {"NAME"};
        Cursor cursor = db.query("MED",colums,null,null,null,null,null);
        long newRowId2 = db.delete("MED","NAME='"+name.getText().toString()+"'",null);

        if (newRowId2 == 1) {
            Toast.makeText(this, "삭제성공", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "삭제", Toast.LENGTH_SHORT).show();
        }

    }

    public void Back(View view) {
        finish();
    }

    @Override
    public void finish() {
        setResult(RESULT_CANCELED);
        super.finish();
    }

}
