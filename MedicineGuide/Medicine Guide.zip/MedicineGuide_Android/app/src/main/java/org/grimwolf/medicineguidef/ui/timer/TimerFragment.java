package org.grimwolf.medicineguidef.ui.timer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.arch.lifecycle.ViewModelProviders;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import org.grimwolf.medicineguidef.DBHelper;
import org.grimwolf.medicineguidef.MainActivity;
import org.grimwolf.medicineguidef.R;
import org.grimwolf.medicineguidef.ui.main.MainFragment;
import org.grimwolf.medicineguidef.ui.main.MainViewModel;

import java.util.ArrayList;
import java.util.Calendar;

public class TimerFragment extends Fragment {
    Context mContext;

    RecyclerView mRecyclerView;                 //리사이클링뷰
    RecyclerView.LayoutManager mLayoutManager;  //리사이클링레이아웃 매니저

    Button m_add_alarm;
    ArrayList<TimerData> timerDataArrayList;
    TimerData mTimerContent;    //다이얼로그에 이름, 내용 값을 전달하기위한 객체

    AlarmManager alarmManager;

    private TimerDialog timerDialog;
    private TimerDialogContent timerDialogContent;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.timer_fragment, container, false);

        //리사이클링뷰 영역----------------------------------------------------------------------------
        mRecyclerView = view.findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(false);
        mLayoutManager = new LinearLayoutManager(mContext);
        mRecyclerView.setLayoutManager(mLayoutManager);

        timerDataArrayList = new ArrayList<TimerData>();
        mTimerContent = new TimerData();
        GetTimerList();
        // DB 처리

        final TimerAdapter timerAdapter = new TimerAdapter(timerDataArrayList);


        mRecyclerView.setAdapter(timerAdapter);
        //리사이클링뷰 영역 끝-------------------------------------------------------------------------
        m_add_alarm = (Button) view.findViewById(R.id.m_add_alarm);
        //m_add_alarm.performClick();   //클릭이밴트 발동시키기
        m_add_alarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                timerDialogContent = new TimerDialogContent(mContext,mTimerContent,new TimerDialogContent.ICustomDialogEventListener() {
                    @Override
                    public void TimerDialogContentEvent(final String name, final String content) {
                        timerDialog = new TimerDialog(mContext, new TimerDialog.ICustomDialogEventListener() {
                            @RequiresApi(api = Build.VERSION_CODES.N)
                            @Override
                            public void TimerDialogEvent(int hour, int min, boolean isRepeat) {
                                Calendar calendar = Calendar.getInstance();


                                if (calendar.get(Calendar.HOUR_OF_DAY) > hour ||
                                        (calendar.get(Calendar.HOUR_OF_DAY) == hour && calendar.get(Calendar.MINUTE) >= min)) {
                                    calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + 1);
                                }
                                calendar.set(Calendar.HOUR_OF_DAY, hour);
                                calendar.set(Calendar.MINUTE, min);
                                calendar.set(Calendar.SECOND, 0);

                                int requestCode = 0;

                                if (timerDataArrayList.size() <= 0) requestCode = 0;
                                else
                                    requestCode = timerDataArrayList.get(timerDataArrayList.size() - 1).getRequestCode() + 1;

                                Intent intent = new Intent(getActivity(),MyAlarmReceiver.class);
                                intent.putExtra("requestCode", requestCode);
                                PendingIntent pendingIntent = PendingIntent.getBroadcast(mContext, requestCode, intent, PendingIntent.FLAG_CANCEL_CURRENT);
                                alarmManager = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
                                Log.e("isRepeat",  String.valueOf(isRepeat));
                                if (isRepeat)
                                    alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), 1000 * 60 * 60 * 24, pendingIntent);
                                else
                                    alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);

                                TimerData timerData = new TimerData(requestCode, hour, min, true, isRepeat, name, content);
                                timerDataArrayList.add(timerData);

                                Insert(timerData);
                                timerAdapter.notifyItemInserted(timerDataArrayList.size() - 1);

                            }
                        });
                        timerDialog.setCancelable(true);
                        timerDialog.getWindow().setGravity(Gravity.CENTER);
                        timerDialog.show();
                    }
                    //timerDialogContent
                });
                timerDialogContent.setCancelable(true);
                timerDialogContent.getWindow().setGravity(Gravity.CENTER);
                timerDialogContent.show();

                mTimerContent = new TimerData();

            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    public void Insert(TimerData timerData) {
        SQLiteDatabase db;
        db = DBHelper.getInstance(mContext).getWritableDatabase();
        boolean sear = true;
        String[] colums = {"REQUESTCODE"};
        Cursor cursor = db.query("DIA", colums, null, null, null, null, null);
        Log.e("TimerData", timerData.toString());
        while (cursor.moveToNext()) {
            if (cursor.getInt(0) == timerData.getRequestCode()) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("HOUR", timerData.getHour());
                contentValues.put("MIN", timerData.getMin());
                contentValues.put("STATUS", String.valueOf(timerData.isStatus()));
                contentValues.put("REPEAT", String.valueOf(timerData.isRepeat()));
                contentValues.put("NAME", timerData.getName());
                contentValues.put("CONTENT", timerData.getContent());
                db.update("DIA", contentValues, null, null);
                sear = false;
            }
        }

        if (sear == true) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("REQUESTCODE", timerData.getRequestCode());
            contentValues.put("HOUR", timerData.getHour());
            contentValues.put("MIN", timerData.getMin());
            contentValues.put("STATUS", String.valueOf(timerData.isStatus()));
            contentValues.put("REPEAT", String.valueOf(timerData.isRepeat()));
            contentValues.put("NAME", timerData.getName());
            contentValues.put("CONTENT", timerData.getContent());

            long newRowId1 = db.insert("DIA", null, contentValues);
        }
    }

    public void GetTimerList() {
        SQLiteDatabase db;
        db = DBHelper.getInstance(mContext).getWritableDatabase();
        String[] colums = {"*"};
        Cursor cursor = db.query("DIA", colums, null, null, null, null, null);
        //db.execSQL("DELETE FROM DIA");
        Log.e("GetTimerRequest", String.valueOf(cursor.getColumnIndex("NAME")));
        while (cursor.moveToNext()) {
            int requestcode = cursor.getInt(1);
            int hour = cursor.getInt(2);
            int min = cursor.getInt(3);
            Boolean status = Boolean.valueOf(cursor.getString(4));
            Boolean repeat = Boolean.valueOf(cursor.getString(5));
            String name = cursor.getString(6);
            String content = cursor.getString(7);
            TimerData timerData = new TimerData(requestcode, hour, min, status, repeat, name, content);
            //Log.e("Result", timerData.toString() );
            timerDataArrayList.add(timerData);
        }

    }
    public void setmTimerContent(String name, String content){
        mTimerContent.setName(name);
        mTimerContent.setContent(content);
        m_add_alarm.performClick();
    }
    public TimerData getmTimerContent(){
        return mTimerContent;
    }
}
