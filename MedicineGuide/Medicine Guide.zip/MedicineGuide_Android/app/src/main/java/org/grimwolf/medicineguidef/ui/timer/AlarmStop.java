package org.grimwolf.medicineguidef.ui.timer;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.grimwolf.medicineguidef.DBHelper;
import org.grimwolf.medicineguidef.R;

public class AlarmStop extends AppCompatActivity {
    TextView aof_content, aof_name;
    TextView aof_hour, aof_min;
    Button alarmstopbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm_stop);

        aof_hour =(TextView) findViewById(R.id.aof_hour);
        aof_min = (TextView)findViewById(R.id.aof_min);
        aof_content = (TextView)findViewById(R.id.aof_content);
        aof_name = (TextView)findViewById(R.id.aof_name);

        Intent intent = getIntent();

        int requestCode = intent.getExtras().getInt("requestCode");
        SetTime(requestCode);

        alarmstopbtn = (Button) findViewById(R.id.alarmstopbtn);
        alarmstopbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        aof_content.setMovementMethod(new ScrollingMovementMethod());

    }

    public void SetTime(int requestCode) {
        SQLiteDatabase db;
        db = DBHelper.getInstance(this).getWritableDatabase();
        String[] colums = {"*"};
        Cursor cursor = db.rawQuery("SELECT * FROM DIA WHERE REQUESTCODE =" + requestCode,null);
        while (cursor.moveToNext()) {
            int hour = cursor.getInt(2);
            int min = cursor.getInt(3);
            Boolean status = Boolean.valueOf(cursor.getString(4));
            Boolean repeat = Boolean.valueOf(cursor.getString(5));
            String name = cursor.getString(6);
            String content = cursor.getString(7);
            if (min < 10)
                aof_min.setText("0" + min);
            else
                aof_min.setText(String.valueOf(min));
            if (hour < 10)
                aof_hour.setText("0" + hour);
            else
                aof_hour.setText(String.valueOf(hour));

            aof_name.setText(name);
            aof_content.setText(content);
            break;
        }

    }

    @Override
    public void finish() {
        stopService(new Intent(getApplicationContext(), MyAlarmService.class));
        NotificationManager notificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(1);
        super.finish();
    }
}

