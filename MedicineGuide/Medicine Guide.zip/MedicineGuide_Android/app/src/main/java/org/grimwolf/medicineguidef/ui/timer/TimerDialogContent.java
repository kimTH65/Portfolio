package org.grimwolf.medicineguidef.ui.timer;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import org.grimwolf.medicineguidef.R;

public class TimerDialogContent extends Dialog {
    public interface ICustomDialogEventListener {
        public void TimerDialogContentEvent(String name, String content);
    }
    private TimerDialogContent.ICustomDialogEventListener onICustomDialogEventListener;

    Context mContext;

    EditText mName, mContent;
    Button mCancelBtn, mOkbtn;

    TimerData mTimerData;

    public TimerDialogContent(Context context, TimerData timerData, ICustomDialogEventListener onICustomDialogEventListener) {
        super(context);
        mContext = context;
        this.onICustomDialogEventListener = onICustomDialogEventListener;
        mTimerData = timerData;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowManager.LayoutParams lpWindow = new WindowManager.LayoutParams();
        lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        lpWindow.dimAmount = 0.8f;
        getWindow().setAttributes(lpWindow);

        setContentView(R.layout.timer_content);


        mName = findViewById(R.id.d_name);
        mContent = findViewById(R.id.d_content);
        mOkbtn = findViewById(R.id.d_content_ok_bth);
        mCancelBtn= findViewById(R.id.d_content_cancel_btn);

        mName.setText(mTimerData.getName());
        mContent.setText(mTimerData.getContent());

        mOkbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onICustomDialogEventListener.TimerDialogContentEvent(mName.getText().toString(), mContent.getText().toString());
                dismiss();
            }
        });
        mCancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

    }
}
