package org.grimwolf.medicineguidef.ui.dbset;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import org.grimwolf.medicineguidef.DBHelper;

public class DBcontentval {
    SQLiteDatabase db;
    Context mContext;
    public void DBcursor(Context context,String name, String inform1, String inform2, String inform3, String draw, String check)
    {
        db = new DBHelper(context).getWritableDatabase();
        String[] colums = {"NAME","INFORM1","INFORM2","INFORM3","DRAW","CEHCK"};
        Cursor cursor = db.query("MED",colums,null,null,null,null,null);

        ContentValues cont = new ContentValues();
        cont.put("NAME", name);
        cont.put("INFORM1", inform1);
        cont.put("INFORM2", inform2);
        cont.put("INFORM3", inform3);
        cont.put("DRAW", draw);
        cont.put("CEHCK", check);
        db.insert("MED", null, cont);

    }

}
