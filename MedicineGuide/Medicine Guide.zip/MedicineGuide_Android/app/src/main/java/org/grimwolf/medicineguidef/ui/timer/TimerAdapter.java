package org.grimwolf.medicineguidef.ui.timer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.grimwolf.medicineguidef.DBHelper;
import org.grimwolf.medicineguidef.R;

import java.util.ArrayList;
import java.util.Calendar;

public class TimerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    TimerDialogReset timerDialogReset;
    TimerDialogContent timerDialogContent;
    AlarmManager alarmManager;

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView row_hour;
        TextView row_min;
        TextView row_status;

        View mView;

        MyViewHolder(View view) {
            super(view);
            mView = view;
            row_hour = (TextView) view.findViewById(R.id.row_hour);
            row_min = (TextView) view.findViewById(R.id.row_min);
            row_status = (TextView) view.findViewById(R.id.row_state);
        }
    }

    private ArrayList<TimerData> timerDataArrayList;

    public TimerAdapter(ArrayList<TimerData> timerDataArrayList) {
        this.timerDataArrayList = timerDataArrayList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.timer_recycler_row, viewGroup, false);

        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, final int position) {
        MyViewHolder myViewHolder = (MyViewHolder) viewHolder;

        if (timerDataArrayList.get(position).getHour() >= 10) {
            myViewHolder.row_hour.setText(String.valueOf(timerDataArrayList.get(position).getHour()));
        } else {
            myViewHolder.row_hour.setText("0" + String.valueOf(timerDataArrayList.get(position).getHour()));
        }
        if (timerDataArrayList.get(position).getMin() >= 10) {
            myViewHolder.row_min.setText(String.valueOf(timerDataArrayList.get(position).getMin()));
        } else {
            myViewHolder.row_min.setText("0" + String.valueOf(timerDataArrayList.get(position).getMin()));
        }
        if (timerDataArrayList.get(position).isStatus()) {
            myViewHolder.row_status.setText("작동중");
        } else {
            myViewHolder.row_status.setText("종료됨");
        }

        ((MyViewHolder) viewHolder).mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Context context = v.getContext();
                timerDialogContent = new TimerDialogContent(context, timerDataArrayList.get(position), new TimerDialogContent.ICustomDialogEventListener() {
                    @Override
                    public void TimerDialogContentEvent(String name, String content) {
                        timerDialogReset = new TimerDialogReset(context, timerDataArrayList.get(position), new TimerDialogReset.ICustomDialogEventListener() {
                            @Override
                            public void TimerDialogResetEvent(TimerData timerData) {
                                int hour = timerData.getHour();
                                int min = timerData.getMin();
                                int requestCode = timerData.getRequestCode();
                                boolean isRepeat = timerData.isRepeat();

                                Calendar calendar = Calendar.getInstance();

                                if (calendar.get(Calendar.HOUR_OF_DAY) > hour ||
                                        (calendar.get(Calendar.HOUR_OF_DAY) == hour && calendar.get(Calendar.MINUTE) >= min)) {
                                    calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + 1);
                                }
                                calendar.set(Calendar.HOUR_OF_DAY, hour);
                                calendar.set(Calendar.MINUTE, min);
                                calendar.set(Calendar.SECOND, 0);

                                Intent intent = new Intent("org.grim.ALARM_START");
                                intent.putExtra("requestCode", requestCode);
                                PendingIntent pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_CANCEL_CURRENT);
                                alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

                                if (isRepeat)
                                    alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), 1000 * 60 * 60 * 24, pendingIntent);
                                else
                                    alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);

                                timerData.setStatus(true);
                                timerDataArrayList.set(position, timerData);
                                UpdateTimerContent(context, timerData);

                                notifyItemChanged(position);
                            }

                            @Override
                            public void TimerDialogDeleteEvent() {
                                TimerData timerData = CancelTimer(position, context);
                                DeleteTimerContent(context, timerData);
                                timerDataArrayList.remove(timerDataArrayList.get(position));
                                notifyItemRemoved(position);
                                notifyItemRangeChanged(position, timerDataArrayList.size());
                            }

                            @Override
                            public void TimerDialogCancelEvent() {
                                CancelTimer(position, context);
                                TimerData timerData = timerDataArrayList.get(position);
                                timerData.setStatus(false);
                                timerDataArrayList.set(position, timerData);
                                UpdateTimerContent(context, timerData);
                                notifyItemChanged(position);
                            }
                        }); //타이머 다이얼로그 끝
                        timerDialogReset.setCancelable(true);
                        timerDialogReset.getWindow().setGravity(Gravity.CENTER);
                        timerDialogReset.show();
                    }
                }); //다이얼로그 컨텐트 끝
                timerDialogContent.setCancelable(true);
                timerDialogContent.getWindow().setGravity(Gravity.CENTER);
                timerDialogContent.show();


            }
        }); //클릭리스너 끝

    }

    @Override
    public int getItemCount() {
        return timerDataArrayList.size();
    }

    public void UpdateTimerContent(Context context, TimerData timerData) {
        SQLiteDatabase db;
        db = DBHelper.getInstance(context).getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put("HOUR", timerData.getHour());
        contentValues.put("MIN", timerData.getMin());
        contentValues.put("STATUS", String.valueOf(timerData.isStatus()));
        contentValues.put("REPEAT", String.valueOf(timerData.isRepeat()));
        contentValues.put("NAME", timerData.getName());
        contentValues.put("CONTENT", timerData.getContent());
        db.update("DIA", contentValues, "REQUESTCODE=" + timerData.getRequestCode() + "", null);
    }

    public void DeleteTimerContent(Context context, TimerData timerData) {
        SQLiteDatabase db;
        db = DBHelper.getInstance(context).getWritableDatabase();
        db.delete("DIA", "REQUESTCODE=" + timerData.getRequestCode() + "", null);
    }

    public TimerData CancelTimer(int position, Context context) {
        TimerData timerData = timerDataArrayList.get(position);
        Intent intent = new Intent("org.grim.ALARM_START");
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, timerData.getRequestCode(), intent, PendingIntent.FLAG_CANCEL_CURRENT);
        alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        alarmManager.cancel(pendingIntent);
        return timerData;
    }

}
