package org.grimwolf.medicineguidef.ui.main;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import org.grimwolf.medicineguidef.R;
import org.grimwolf.medicineguidef.ui.dbset.DBcontentval;
import org.grimwolf.medicineguidef.ui.guide.GuideFragment;
import org.grimwolf.medicineguidef.ui.timer.TimerFragment;

public class MainFragment extends Fragment {

    private MainViewModel mViewModel;

    Button m_guidebtn, m_timerbtn, m_exitbtn;

    FragmentManager fragmentManager;

    Context mContext;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    public static MainFragment newInstance() {
        return new MainFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.main_fragment, container, false);

        DBcontentval cont = new DBcontentval();
        cont.DBcursor(mContext,"타이레놀","해열 및 감기에 의한 통증과 두통, 치통, 근육통, 허리통증, 생리통, 관절통의 완화",
                                                    "매 8시간마다 4정씩 복용 , 24시간동안 12정을 초과하지 말것",
                                                    "이 약은 서방형 제제이므로 정제를 으깨거나 씹거나 녹이지 말고 그대로 삼켜서 복용해야 한다.","a1","false");
        cont.DBcursor(mContext,"게보린정","오한(춥고 떨리는 증상), 발열시의 해열,두통, 치통, 발치(이를 뽑음)후 동통(통증), 인후(목구멍)통",
                                                    "성인 1회 1정 1일 3회까지 공복(빈속)시를 피하여 복용한다.\n" +
                                                             "복용간격은 4시간 이상으로 한다.",
                                                    "직사일광을 피하고 될 수 있는 한 습기가 적은 서늘한 곳에 보관할 것.","a2","false");
        cont.DBcursor(mContext,"소론도정","내분비 장애, 류마티스성 장애, 교원성 질환, 피부 질환, 알레르기성 질환, 안과 질환 ",
                                                    "성인 1일 5-60mg을 1-4회 분할 경구투여한다. ",
                                                    "어린이 손이 닿지 않는 곳에 보관한다.","a3","false");
        cont.DBcursor(mContext,"알마겔정","위·십이지장궤양, 위염, 위산과다, 속쓰림, 구역, 구토, 위통, 신트림",
                                                    "알마게이트로서 1회 1 g을 1일 3회, 식후 30분 ∼ 1시간에 씹어서 경구 복용한다.",
                                                    "직사광선을 피하고 되도록 습기가 적은 서늘한 곳에 보관할 것.","a4","false");
        cont.DBcursor(mContext,"뮤코라제정","수술 및 외상후, 부비동염, 혈전정맥염, 호흡기 질환에 수반하는 담객출 곤란",
                                                    "1회 1 ∼ 2정, 1일 4회 경구투여한다. ",
                                                    "어린이 손이 닿지 않는 곳에 보관한다.","a5","false");

        fragmentManager = getActivity().getSupportFragmentManager();

        m_guidebtn = view.findViewById(R.id.Guide);
        m_timerbtn = view.findViewById(R.id.Timer);
        m_exitbtn = view.findViewById(R.id.Exit);



        m_guidebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.container,new GuideFragment());
                fragmentTransaction.addToBackStack(null).commit();
            }
        });
        m_timerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.container,new TimerFragment());
                fragmentTransaction.addToBackStack(null).commit();
            }
        });
        m_exitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        });
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(MainViewModel.class);
        // TODO: Use the ViewModel
    }

}
