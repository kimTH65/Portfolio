<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Registpro extends Model
{
    use \Illuminate\Database\Eloquent\SoftDeletes;
    
    protected $table = 'registpro';
    protected $fillable = ['name','classAndDepart','title','category','content','price','image'];
    protected $dates =['deleted_at'];
    
}
