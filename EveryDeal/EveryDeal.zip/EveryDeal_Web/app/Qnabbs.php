<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Qnabbs extends Model
{
    use \Illuminate\Database\Eloquent\SoftDeletes;
    
    protected $table = 'qnabbs';
    protected $fillable = ['name','title','content'];
    protected $dates =['deleted_at'];
    
}
