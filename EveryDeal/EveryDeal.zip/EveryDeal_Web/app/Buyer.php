<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Buyer extends Model
{
    use \Illuminate\Database\Eloquent\SoftDeletes;
    
    protected $table = 'buyer';
    protected $fillable = ['userid','contact','price','productid'];
    protected $dates =['deleted_at'];
    
}
