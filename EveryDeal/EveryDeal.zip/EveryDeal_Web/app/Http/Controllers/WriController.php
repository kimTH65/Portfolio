<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WriController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $id = \Illuminate\Support\Facades\Auth::id();
        $regist = \App\Registpro::where('userid',$id)->get();
        //$regist = \App\Registpro::orderBy('created_at','desc')->paginate(5);
        
       // $regist = \App\Registpro::all();
        
        return view('mywriting', compact('regist'));
    }
    
    
    public function delete(Request $request)
    {
        $id = $request->input('id');
        $regist = \App\Registpro::find($id);
        $regist->delete();
        
        $userid = \Illuminate\Support\Facades\Auth::id();
        $regist = \App\Registpro::where('userid',$userid)->get();
        
        return view('mywriting', compact('regist'));
    }
    
    public function buyerList(Request $request)
    {
        $id = $request->input('id');
        $buyer = \App\Buyer::where('productid',$id)->get();
        
        return view('buyerlist',compact('buyer'));
    }
}
