<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RegistController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('qnabbs');
    }

    public function qnabbsinsert(Request $request)
    {
        $id = \Illuminate\Support\Facades\Auth::id();
        $user = \App\User::find($id);
        
        $qnabbs = new \App\Qnabbs();
        
        $qnabbs->save();
        $regist = \App\Registpro::orderBy('created_at','desc')->paginate(9);
        
        return view('deal', compact('regist'));
    }
}
