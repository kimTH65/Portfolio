<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SelController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
        $userid = \Illuminate\Support\Facades\Auth::id();
        $id = $request->input('id');
        
        $regist = \App\Registpro::find($id);
        return view('sel', compact('regist','userid','id'));
    }
    
    
    
    
}
