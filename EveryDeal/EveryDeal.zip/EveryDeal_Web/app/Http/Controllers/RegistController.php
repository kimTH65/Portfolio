<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RegistController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $id = \Illuminate\Support\Facades\Auth::id();
        $user = \App\User::find($id);
        $name = $user->name;
        $classof = $user->classof;
        $department = $user->department;
        
        return view('regist', compact('name','classof','department'));
    }

    public function regist(Request $request)
    {
        $id = \Illuminate\Support\Facades\Auth::id();
        $user = \App\User::find($id);
        
        $registpro = new \App\Registpro();
        $registpro->name = $user->name;
        $registpro->classAndDepart = $user->classof." ".$user->department;
        $registpro->title = $request->input('title');
        $registpro->category = $request->input('category');
        $registpro->content = $request->input('content');
        $registpro->price = $request->input('price');
        $registpro->userid = $id;
        
        if($request->hasfile('image')){
            $file = $request->file('image');
            $extension = $file -> getClientOriginalExtension();
            $filename = time() . "." . $extension;
            $file->move('upload/registpro/',$filename);
            $registpro->image = $filename;
        } else {
            //이줄 지울게요 필요 없는것 같아서return view('regist');
            $registpro->image ='';
        }
        
        $registpro->save();
        $regist = \App\Registpro::orderBy('created_at','desc')->paginate(9);
        echo "<script>alert(\"등록에 성공하셨습니다.\");</script>";
        return view('deal', compact('regist'));
    }
}
