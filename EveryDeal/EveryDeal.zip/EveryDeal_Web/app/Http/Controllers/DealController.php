<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DealController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
        $regist = \App\Registpro::orderBy('created_at','desc')->paginate(6);
        
        if ($request->has('search')) {
            $regist = \App\Registpro::where(
                'title', 'like', '%'.$request->input('search').'%'
            )->paginate(6);
        }
        
        if ($request->has('select')) {
            $regist = \App\Registpro::where(
                'category', 'like', '%'.$request->input('select').'%'
            )->paginate(6);
        }
        
       // $regist = \App\Registpro::all();
        
        return view('deal', compact('regist'));
    }
    
    
}
