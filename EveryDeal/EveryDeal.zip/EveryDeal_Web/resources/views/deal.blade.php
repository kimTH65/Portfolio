@extends('layouts.app') @section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              <center><div class="card-header">거래하기</div></center>


                <div id="search_box">
                <form method="get" action="{{ route('deal') }}" class="form-inline pull-right">
                    <div class="form-group">
                        <input type="text" name="search"  size="50" class="form-control" id="search" placeholder="검색어">
                    </div>
                    <button type="submit" class="btn btn-default">검색</button>
                </form>
                </div>

              <div id="search_box2">
                <form method="get" action="{{ route('deal') }}" class="form-inline pull-right">
                    <div class="form-group">

                        <select class="form-control" id="select" name="select">
                        <option>전체</option>
                        <option>책</option>
                        <option>방</option>
                        <option>기타</option>
                      </select>
                    </div>
                    <button type="submit" class="btn btn-default">선택</button>
                </form>
              </div>

                   <div class="card-bpdy">
                     @foreach ($regist->chunk(3) as $chunk)
                    <ul class="row">
                        @foreach ($chunk as $product)
                        <li class="col-sm-4">
                            <h4>
                                <a href="/sel/?id={{$product['id']}}">
                                  {{ str_limit($product->title, 40) }}
                                </a>
                            </h4>
                            <div>
                                <a href="/sel/?id={{$product['id']}}">
                                   <image style="width:200px; height: 200px;" src="upload/registpro/{{$product['image']}}" class="img-responsive">
                                </a>
                            </div>
                            <div>
                                <ul>
                                    <li>
                                        {{$product['price'] }}원
                                    </li>
                                </ul>
                            </div>
                        </li>
                        @endforeach
                    </ul>
                    @endforeach
                 
                    <div class="">
                        {!! $regist->render()!!}

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
