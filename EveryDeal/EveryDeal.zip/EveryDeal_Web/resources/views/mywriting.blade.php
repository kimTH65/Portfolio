@extends('layouts.app')

@section('content')

<link rel="stylesheet" type="text/css" href="/css/style.css" />

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <center><div class="card-header">내가 쓴 글</div></center>

                <div class="card-body">

                 <table class="table table-hover">
                     <thead>
                         <tr>
                           <th width="90">번호</th>
                           <th width="170">카테고리</th>
                           <th width="500">제목</th>
                           <th width="200">날짜</th>
                           <th width="200">목록/삭제</th>
                         </tr>
                     </thead>
                     <tbody>
                         @foreach($regist as $regi)

                         <tr >

                             <td>{{$regi['id'] }}</td>
                             <td>{{$regi['category'] }}</td>
                             <td>{{$regi['title'] }}</td>
                             <td>{{$regi['created_at'] }}</td>
                             <td>

                                <button type="button" onclick="location.href='/buyerList/?id={{$regi['id']}}'" class="btn btn-primary btn-block">구매 요청자 목록</button>
                                <button type="button" onclick="location.href='/wriDel/?id={{$regi['id']}}'" class="btn btn-primary btn-block">삭제하기</button>
                             </td>
                         </tr>
                         @endforeach
                     </tbody>





                </table>
                 <div class="">
                         {{--{!! $regist->render()!!}--}}

                     </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
