@extends('layouts.app') @section('content')

<link rel="stylesheet" type="text/css" href="/css/style.css" />

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">거래하기</div>


                <div class="card-body">

                  <div id="search_box2">
                  <form method="get" action="{{ route('deal') }}" class="form-inline pull-right" >
                      <div class="form-group">
                          <select class="form-control" id="select" name="select">
                          <option>전체</option>
                          <option>책</option>
                          <option>방</option>
                          <option>기타</option>
                        </select>
                      </div>
                      <button type="submit" class="btn btn-default">선택</button>
                  </form>
                </div>

                    <table class="table table-hover">
                        <thead>
                            <tr>
                              <th width="90">번호</th>
                              <th width="170">카테고리</th>
                              <th width="500">제목</th>
                              <th width="130">작성자</th>
                              <th width="200">날짜</th>
                            </tr>

                        </thead>
                        <tbody>
                            @foreach($regist as $regi)

                            <tr onclick="location.href='/sel/?id={{$regi['id']}}'">

                                <td>{{$regi['id'] }}</td>
                                <td>{{$regi['category'] }}</td>
                                <td>{{$regi['title'] }}</td>
                                <td>{{$regi['name']}}</td>
                                <td>{{$regi['created_at'] }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <div id="search_box">
                    <form method="get" action="{{ route('deal') }}" class="form-inline pull-right">
                        <div class="form-group">
                            <input type="text" name="search" size="40" class="form-control" id="search" placeholder="검색어">
                        </div>
                        <button type="submit" class="btn btn-default">검색</button>
                    </form>
                  </div>

                    <div class="">
                        {!! $regist->render()!!}

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
