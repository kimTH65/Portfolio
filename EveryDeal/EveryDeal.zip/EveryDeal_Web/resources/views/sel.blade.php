@extends('layouts.app')

<link rel="stylesheet" type="text/css" href="/css/style.css" />

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              <center>  <div class="card-header">상품정보</div> </center>

                <div class="card-body">

                    <table class="table table" >
                        <thead>
                        </thead>
                        <tbody>
                            <tr>
                                 <td colspan = "2"><image src="upload/registpro/{{$regist['image']}}" style="width:600px;height:400px "></td>
                            </tr>
                        </tbody>
                        <tbody>
                            <tr>
                                <th style="background-color: buttonface">제목 </th>
                                <td  >{{$regist['title'] }}</td>
                            </tr>
                            <tr>
                                <th style="background-color: buttonface">이름 </th>
                                <td >{{$regist['name'] }}</td>
                            </tr>

                            <tr>
                                <th style="background-color: buttonface">학번 학과</th>
                                <td>{{$regist['classAndDepart']}}</td>
                            </tr>
                            <tr>
                                <th style="background-color: buttonface">카테고리</th>
                                <td>{{$regist['category'] }}</td>

                            </tr>
                            <tr>
                                <th style="background-color: buttonface">작성일</th>
                                <td>{{$regist['created_at'] }}</td>

                            </tr>
                            <tr>

                            </tr>
                            <tr>
                                <th style="background-color: buttonface">내용</th>
                                <td colspan="4" >{{$regist['content'] }} </textarea></td>
                            </tr>
                            <tr>
                                <th style="background-color: buttonface">가격</th>
                                <td>{{$regist['price'] }}</td>
                            </tr>


                        </tbody>
                    </table>
                @if($regist['userid']!=$userid)
                <form action="{{ route('buyer')}}" method="POST">
                    @csrf
                <div>
                    <hr>
                    <h4>거래 요청</h4>
                    <br>
                    전화번호
                    <input type="text" name="contact" class="form-control">
                    <br>
                    가격
                    <input type="text" name="price" class="form-control">
                    <br>
                </div>
                   <input type="hidden" name="id" value="{{$id}}">
                   <input type="hidden" name="productid" value="{{$regist['id']}}">
                <button type="submit" name="submit" class="btn btn-primary btn-block"  >거래 요청</button>

                @endif
                </form>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
