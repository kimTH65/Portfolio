@extends('layouts.app') @section('content')
<link rel="stylesheet" type="text/css" href="/css/style.css" />
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <center><div class="card-header">구매자 희망자</div></center>

                <div class="card-body">

                    <table class="table table-hover">
                        <thead>
                            <tr>
                              <th width="170">연락처</th>
                              <th width="500">가격</th>
                              <th width="200">날짜</th>
                            </tr>

                        </thead>
                        <tbody>
                            @foreach($buyer as $buy)

                            <tr>

                                <td>{{$buy['contact']}}</td>
                                <td>{{$buy['price']}}</td>
                                <td>{{$buy['created_at']}}</td>
                                <td>

                                </td>
                            </tr>
                            @endforeach
                        </tbody>

                    </table>
                    <div class="">
                        {{--{!! $regist->render()!!}--}}

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
