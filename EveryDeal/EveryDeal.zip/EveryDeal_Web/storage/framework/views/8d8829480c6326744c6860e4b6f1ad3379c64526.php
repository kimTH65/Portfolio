<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">거래하기</div>

                <div class="card-body">
                 
                 <table class="table table-hover">
                     <thead>
                         <tr>
                             <th>번호</th>
                             <th>카테고리</th>
                             <th>제목</th>
                             <th>작성자</th>
                             <th>날짜</th>
                         </tr>
                         
                     </thead>
                     <tbody>
                         <?php $__currentLoopData = $regist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                         <tr onclick="location.href='/sel/?id=<?php echo e($regi['id']); ?>'">
                             
                             <td><?php echo e($regi['id']); ?></td>
                             <td><?php echo e($regi['category']); ?></td>
                             <td><?php echo e($regi['title']); ?></td>
                             <td><?php echo e($regi['name']); ?></td>
                             <td><?php echo e($regi['created_at']); ?></td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     
                         
                     
                     
                     
                </table>
                 <div class="">
                         <?php echo $regist->render(); ?>

                         
                     </div>
                 
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Practice12\resources\views/deal.blade.php ENDPATH**/ ?>