<link rel="stylesheet" type="text/css" href="/css/style.css" />

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              <center>  <div class="card-header">상품정보</div> </center>

                <div class="card-body">

                    <table class="table table" >
                        <thead>
                        </thead>
                        <tbody>
                            <tr>
                                 <td colspan = "2"><image src="upload/registpro/<?php echo e($regist['image']); ?>" style="width:600px;height:400px "></td>
                            </tr>
                        </tbody>
                        <tbody>
                            <tr>
                                <th style="background-color: buttonface">제목 </th>
                                <td  ><?php echo e($regist['title']); ?></td>
                            </tr>
                            <tr>
                                <th style="background-color: buttonface">이름 </th>
                                <td ><?php echo e($regist['name']); ?></td>
                            </tr>

                            <tr>
                                <th style="background-color: buttonface">학번 학과</th>
                                <td><?php echo e($regist['classAndDepart']); ?></td>
                            </tr>
                            <tr>
                                <th style="background-color: buttonface">카테고리</th>
                                <td><?php echo e($regist['category']); ?></td>

                            </tr>
                            <tr>
                                <th style="background-color: buttonface">작성일</th>
                                <td><?php echo e($regist['created_at']); ?></td>

                            </tr>
                            <tr>

                            </tr>
                            <tr>
                                <th style="background-color: buttonface">내용</th>
                                <td colspan="4" ><?php echo e($regist['content']); ?> </textarea></td>
                            </tr>
                            <tr>
                                <th style="background-color: buttonface">가격</th>
                                <td><?php echo e($regist['price']); ?></td>
                            </tr>


                        </tbody>
                    </table>
                <?php if($regist['userid']!=$userid): ?>
                <form action="<?php echo e(route('buyer')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                <div>
                    <hr>
                    <h4>거래 요청</h4>
                    <br>
                    전화번호
                    <input type="text" name="contact" class="form-control">
                    <br>
                    가격
                    <input type="text" name="price" class="form-control">
                    <br>
                </div>
                   <input type="hidden" name="id" value="<?php echo e($id); ?>">
                   <input type="hidden" name="productid" value="<?php echo e($regist['id']); ?>">
                <button type="submit" name="submit" class="btn btn-primary btn-block"  >거래 요청</button>

                <?php endif; ?>
                </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\KingEun\Practice13\resources\views/sel.blade.php ENDPATH**/ ?>