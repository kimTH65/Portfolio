 <?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="/css/style.css" />
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <center><div class="card-header">구매자 희망자</div></center>

                <div class="card-body">

                    <table class="table table-hover">
                        <thead>
                            <tr>
                              <th width="170">연락처</th>
                              <th width="500">가격</th>
                              <th width="200">날짜</th>
                            </tr>

                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $buyer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td><?php echo e($buy['contact']); ?></td>
                                <td><?php echo e($buy['price']); ?></td>
                                <td><?php echo e($buy['created_at']); ?></td>
                                <td>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                    <div class="">
                        

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Practice12\resources\views/buyerlist.blade.php ENDPATH**/ ?>