<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="/css/style.css" />

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <center><div class="card-header">등록하기</div></center>


                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <div class="alert alert-success" role="alert">

                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form  action="<?php echo e(route('registph')); ?>" method="POST" enctype="multipart/form-data" >
                        <?php echo csrf_field(); ?>
                    <div class = "form-group">

                        <label>제목</label>
                        <input type ="text" class="form-control" name="title"  style="width: 80%">

                        <label>카테고리</label>
                        <br>
                        <div class="form-control" style="width: 50%">
                        <input type="radio" class="" name="category" value="책" > 책 &nbsp;&nbsp;&nbsp;
                        <input type="radio" class="" name="category" value="방" > 방 &nbsp;&nbsp;&nbsp;
                        <input type="radio" class="" name="category" value="기타" > 기타<br>
                        </div>

                        <label>내용</label>
                        <textarea class="form-control" name="content" rows="6"></textarea>

                        <label>가격</label>
                        <input type ="text" class="form-control" name="price"  style="width: 50%">
                        <label>사진 선택 </label>

                        <input type="file" name="image" class="form-control">
                    </div>




                    <br>
                    <br>
                    <button type="submit" name="submit" class="btn btn-primary btn-block" >등록 하기</button>


                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Practice_2\resources\views/regist.blade.php ENDPATH**/ ?>