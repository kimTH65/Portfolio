 <?php $__env->startSection('content'); ?>

<link rel="stylesheet" type="text/css" href="/css/style.css" />

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              <center><div class="card-header">거래하기</div></center>


                <div id="search_box">
                <form method="get" action="<?php echo e(route('deal')); ?>" class="form-inline pull-right">
                    <div class="form-group">
                        <input type="text" name="search"  size="50" class="form-control" id="search" placeholder="검색어">
                    </div>
                    <button type="submit" class="btn btn-default">검색</button>
                </form>
                </div>

              <div id="search_box2">
                <form method="get" action="<?php echo e(route('deal')); ?>" class="form-inline pull-right">
                    <div class="form-group">

                        <select class="form-control" id="select" name="select">
                        <option>전체</option>
                        <option>책</option>
                        <option>방</option>
                        <option>기타</option>
                      </select>
                    </div>
                    <button type="submit" class="btn btn-default">선택</button>
                </form>
              </div>




                    <!--
                       <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>번호</th>
                                <th>카테고리</th>
                                <th>제목</th>
                                <th>작성자</th>
                                <th>날짜</th>
                            </tr>

                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $regist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr onclick="location.href='/sel/?id=<?php echo e($regi['id']); ?>'">

                                <td><?php echo e($regi['id']); ?></td>
                                <td><?php echo e($regi['category']); ?></td>
                                <td><?php echo e($regi['title']); ?></td>
                                <td><?php echo e($regi['name']); ?></td>
                                <td><?php echo e($regi['created_at']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                    -->

                    <div class="card-body">

                      <table class="table table-hover">
                        <thead>
                    <?php $__currentLoopData = $regist->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul class="row">
                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <center>
                            <h4 class="col-sm-4">
                                <a href="/sel/?id=<?php echo e($product['id']); ?>">
                                  <?php echo e(str_limit($product->title, 40)); ?>

                                </a>
                            </h4>
                          </center>
                        </tr>
                        <tr>
                          <center>
                            <div>
                                <a href="/sel/?id=<?php echo e($product['id']); ?>">
                                   <image src="upload/registpro/<?php echo e($product['image']); ?>" class="img-responsive">
                                </a>
                            </div>
                          </center>
                        </tr>
                        <tr>
                            <div>
                                <ul>

                                      <center>
                                        <h2 class="price">
                                        <?php echo e($product['price']); ?>원
                                      </h2>
                                      </center>

                                </ul>
                            </div>

                      </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </thead>
                </table>
                    <div class="">
                        <?php echo $regist->render(); ?>


                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Practice12\resources\views/deal.blade.php ENDPATH**/ ?>