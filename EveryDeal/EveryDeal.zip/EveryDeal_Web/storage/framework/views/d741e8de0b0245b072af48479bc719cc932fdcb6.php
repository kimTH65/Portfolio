<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">내가 쓴 글</div>

                <div class="card-body">
                 
                 <table class="table table-hover">
                     <thead>
                         <tr>
                             <th>번호</th>
                             <th>카테고리</th>
                             <th>제목</th>
                             <th>날짜</th>
                             <th></th>
                         </tr>
                         
                     </thead>
                     <tbody>
                         <?php $__currentLoopData = $regist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                         <tr >
                             
                             <td><?php echo e($regi['id']); ?></td>
                             <td><?php echo e($regi['category']); ?></td>
                             <td><?php echo e($regi['title']); ?></td>
                             <td><?php echo e($regi['created_at']); ?></td>
                             <td> 
                                 
                                <button type="button" onclick="location.href='/buyerList/?id=<?php echo e($regi['id']); ?>'" class="btn btn-primary btn-block">구매 요청자 목록</button>
                                <button type="button" onclick="location.href='/wriDel/?id=<?php echo e($regi['id']); ?>'" class="btn btn-primary btn-block">삭제하기</button>
                             </td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     
                         
                     
                     
                     
                </table>
                 <div class="">
                         
                         
                     </div>
                 
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\KingEun\Practice12\resources\views/mywriting.blade.php ENDPATH**/ ?>