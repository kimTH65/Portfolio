<!doctype html>


<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Sunflower:300&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/mainpage.css')); ?>" rel="stylesheet">
    <style>
        .inner mid-inner div {
            border: 1px solid blue;
        }

        .common-bg {
            background: url(/image/src.png) no-repeat;
        }

        .business-header1 {
            height: 400px;
            background: url(/image/1.jpg) center center no-repeat scroll;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
            -o-background-size: cover;
        }

        .business-header2 {
            height: 400px;
            background: url(/image/2.jpg) center center no-repeat scroll;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
            -o-background-size: cover;
        }

        .business-header3 {
            height: 400px;
            background: url(/image/3.jpg) center center no-repeat scroll;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
            -o-background-size: cover;
        }

    </style>
    <title>ed</title>


</head>

<body>
    <div id="wrap" class="main_wrap">
        <div class="header">
            <div class="top-header">
                <div class="inner top-inner">
                    <h2><a href="http://localhost:8081/">&nbsp;&nbsp;Everydeal</a></h2>
                    <ul id="top_header_login_status">
                        <div class="flex-center position-ref full-height">
                            <?php if(Route::has('login')): ?>
                            <div class="top-right liks2">
                                <?php if(auth()->guard()->check()): ?>
                                <a href="<?php echo e(url('/')); ?>">
                                </a> <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>">로그인</a> <?php if(Route::has('register')): ?>
                                <a href="<?php echo e(route('register')); ?>">회원가입</a> <?php endif; ?> <?php endif; ?>
                            </div>
                            <?php endif; ?>

                    </ul>

                    </div>
                </div>
                <div class="mid-header">

                    <div class="inner mid-inner">
                        <div class="src-box">

                            <form method="get" action="<?php echo e(route('deal')); ?>" name="frmSearch" id="frmSearch">
                                <div class="form-group">
                                    <input type="text" placeholder="제목으로 검색하세요." name="search" value="" autocomplete="off" id="search"></div>
                                <button type="submit" class="src_btn common-bg" id="btnFormSchSubmit"></button>
                            </form>
                        </div>
                        <ul class="ico_ul">
                            <li class="ico01"><a href="<?php echo e(route('deal')); ?>">거래하기</a></li>
                            <li class="ico02"><a href="<?php echo e(route('regist')); ?>">등록하기</a></li>
                            <li class="ico03"><a href="<?php echo e(route('mywriting')); ?>">내가 쓴 글</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!--  이벤트  -->
            <div>
                <div id="demo" class="carousel slide" data-ride="carousel">

                    <!-- Indicators -->
                    <ul class="carousel-indicators">
                        <li data-target="#demo" data-slide-to="0" class="active"></li>
                        <li data-target="#demo" data-slide-to="1"></li>
                        <li data-target="#demo" data-slide-to="2"></li>
                    </ul>

                    <!-- The slideshow -->
                    <div class="carousel-inner">
                        <div class="carousel-item active business-header1">
<!--
                            <div class="carousel-caption">
                                <h3 style="margin-right:800px;">책</h3>
                                
                            </div>
-->
                        </div>
                        <div class="carousel-item business-header2">

                        </div>
                        <div class="carousel-item business-header3">

                        </div>
                    </div>

                    <!-- Left and right controls -->
                    <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            </a>
                    <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
            </a>
                </div>
            </div>
            <!--  항목1  -->
            <div class="inner" style="margin-top:20px;">
                <h1>등록 상품</h1>
                <div>
                     <?php $__currentLoopData = $regist->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul class="row">
                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="col-sm-4">
                            <h4>
                                <a href="/sel/?id=<?php echo e($product['id']); ?>">
                                  <?php echo e(str_limit($product->title, 40)); ?>

                                </a>
                            </h4>
                            <div>
                                <a href="/sel/?id=<?php echo e($product['id']); ?>">
                                    <image style="width:230px; height: 230px;"src="upload/registpro/<?php echo e($product['image']); ?>" class="img-responsive">
                                </a>
                            </div>
                            <div>
                                <ul>
                                    <li>
                                        <?php echo e($product['price']); ?>원
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                    <div class="">
                        <?php echo $regist->render(); ?>


                    </div>

                </div>
            </div>
        </div>
        
        
</body>

</html>
<?php /**PATH D:\Practice_2\resources\views/index.blade.php ENDPATH**/ ?>