<html>
    <head></head>
    <body>
        <div>
        <table><thead><div><td>sss</td></div></thead></table>
        
        </div>
    </body>
</html><?php /**PATH C:\Users\KingEun\Practice13\resources\views/welcome.blade.php ENDPATH**/ ?>