<?php
    use Illuminate\Support\Facades\Hash;
    header("Content-Type: text/html; charset=UTF-8");
    $conn = mysqli_connect("127.0.0.1","root","","everydeal");
    mysqli_set_charset($conn,"utf-8");

    session_start();
    $useremail = $_POST['email'];
    $password = $_POST['password'];
    
    
        
    $result = mysqli_query($conn,"select password from users where email = '$useremail'");
    $passresult;
    while($row = mysqli_fetch_array($result) )
    {
        $passresult = $row[0];
    }
    $count = 1;
    if(password_verify($password, $passresult))
    {
        $count = 1;
    }
   
    if($count==1) {
        
	echo $count;
    }
    else
    {
        echo 0;
    }
   
   mysqli_close($conn);
?>
