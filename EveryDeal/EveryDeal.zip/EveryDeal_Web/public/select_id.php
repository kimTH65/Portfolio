<?php
    header("Content-Type: text/html;charset=utf-8");
    $conn = mysqli_connect("127.0.0.1","root","","everydeal");
    mysqli_set_charset($conn,"utf8");
    
    $id = $_POST['id'];
    $result = mysqli_query($conn,"select * from registpro where id = '$id'");
    
    $data = array();
    
    if($result){
        while($row= mysqli_fetch_array($result)){
            array_push($data,
                    array('id'=>$row[0],
                        'name'=>$row[1],
                        'classAndDepart'=>$row[2],
                        'title'=>$row[3],
                        'category'=>$row[4],
                        'content'=>$row[5],
                        'price'=>$row[6],
                        'image'=>$row[7],
                        'userid'=>$row[8],
                        'created_at'=>$row[9]
                        ));
        }
        
    
    $json = json_encode(array("registpro"=>$data), JSON_PRETTY_PRINT+JSON_UNESCAPED_UNICODE);
 
    echo $json;
    }
     
    
    mysqli_close($conn);
?>
