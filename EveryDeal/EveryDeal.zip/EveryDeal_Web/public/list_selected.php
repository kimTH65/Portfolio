<?php
    header("Content-Type: text/html;charset=utf-8");
    $conn = mysqli_connect("127.0.0.1","root","","everydeal");
    mysqli_set_charset($conn,"utf8");
    
    $productid = $_POST['productid'];
    
    
    $result = mysqli_query($conn,"select * from buyer where productid = '$productid'");
    
    $data = array();
    
    if($result){
        while($row= mysqli_fetch_array($result)){
            array_push($data,
                    array('contact'=>$row[3],
                        'price'=>$row[4],
                        'created_at'=>$row[5]
                        ));
        }
        
    
    $json = json_encode(array("buyer"=>$data), JSON_PRETTY_PRINT+JSON_UNESCAPED_UNICODE);
 
    echo $json;
    }
     
    
    mysqli_close($conn);
?>
