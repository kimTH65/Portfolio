<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRegistproTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('registpro', function (Blueprint $table) {
            $table->bigIncrements('id');
            
            $table->string('name');
            $table->string('classAndDepart');
            
            $table->string('title');
            $table->string('category');
            $table->string('content');
            $table->string('price');
            $table->mediumText('image')->nullable();
            $table->string('userid');
            $table->timestamps();
            $table->date('deleted_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('registpro');
    }
}
