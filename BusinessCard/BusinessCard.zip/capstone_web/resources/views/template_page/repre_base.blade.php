<img src="../UserUploads/{{$repre->user_id}}/{{$repre->img_name}}" alt="My Image" width = "100%">

    