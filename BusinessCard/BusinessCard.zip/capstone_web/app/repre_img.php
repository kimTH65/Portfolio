<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class repre_img extends Model
{
    //
}
