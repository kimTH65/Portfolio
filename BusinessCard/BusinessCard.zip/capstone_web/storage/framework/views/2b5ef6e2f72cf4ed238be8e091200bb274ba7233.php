<?php
      session_start();
      session_destroy();
?>
<meta http-equiv="refresh" content="0;url=/" /><?php /**PATH /var/www/html/capstone/resources/views//logout.blade.php ENDPATH**/ ?>