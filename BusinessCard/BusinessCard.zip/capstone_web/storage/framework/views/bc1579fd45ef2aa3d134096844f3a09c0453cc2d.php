/*<?php
    
 function goto_caution($msg, $url)
    {
        $str = "<script>";
        $str .= "alert('{$msg}');";
        $str .= "location.href = '{$url}';";
        $str .= "</script>";
        echo("$str");
        exit;
    }

$tmpfile =  $_FILES['b_file']['tmp_name'];
$o_name = $_FILES['b_file']['name'];
$filename = iconv("UTF-8", "EUC-KR",$_FILES['b_file']['name']);
$folder = "./board_image/".$filename;


move_uploaded_file($tmpfile,$folder);

?>*/
<?php $__currentLoopData = $boa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   $boas;
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /var/www/html/capstone/resources/views//write_ok.blade.php ENDPATH**/ ?>