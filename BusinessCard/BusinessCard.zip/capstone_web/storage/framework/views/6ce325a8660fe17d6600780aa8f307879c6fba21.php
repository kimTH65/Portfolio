<img src="../UserUploads/<?php echo e($repre->user_id); ?>/<?php echo e($repre->img_name); ?>" alt="My Image" width = "100%">

    <?php /**PATH /var/www/html/capstone/resources/views/template_page/repre_base.blade.php ENDPATH**/ ?>