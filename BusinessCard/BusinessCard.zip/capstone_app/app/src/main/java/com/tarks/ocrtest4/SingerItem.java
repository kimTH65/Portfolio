package com.tarks.ocrtest4;

public class SingerItem {

    private String image;

    public SingerItem(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
